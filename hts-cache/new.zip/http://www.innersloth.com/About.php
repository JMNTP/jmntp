<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>About</title>
<!--Website css base stuffs-->
<link rel="stylesheet" type="text/css" href="websiteStyle.css">
<link href="//cdn-images.mailchimp.com/embedcode/classic-10_7.css" rel="stylesheet" type="text/css">\
<style>
/*About page stuff*/
	
/*Team bio columns stuff*/

/*
.bioColumns {
	float: left;
	padding: 2%;
	margin: 2%;
	max-width: 300px;
	width: 32%;
	min-height: 350px;
	background-color: green;
}
.row:after {
	content: "";
	display: table;
	clear: both;
}*/

/*	
#container {
	width: 100%;
	margin: 0 auto;
}
div#container p {
	text-align: center;
	float: left;
	width: 25%;
	margin: 1.5%;
	padding: 0px 1% 2% 1%;
	min-height: 250px;
	height: auto;
	background-color: yellow;
	font-size: calc(8px + .5vw); found here: https://stackoverflow.com/questions/23560087/is-there-such-a-thing-as-min-font-size-and-max-font-size
}
*/
	
.bioImage {
	max-width: 200px;
	width: 80%;
	height: auto;
}
/*below found https://stackoverflow.com/questions/16908958/css-3-column-liquid-layout-with-fixed-center-column*/
#centerPost {
	background: #999;
	float: left;
}
#leftPost {
	background: #999;
	float: left;
}
#rightPost {
	background: #999;
	float: right;
}
#centerPost, #leftPost, #rightPost {
	font-size: calc(6px + .4vw);
	min-height: 450px;
	width: 24.5%;
	height: auto;
	margin: 1% 2.39%;
	padding: 3.5% 2%;
	max-width: 325px;
	text-align: center;
}
.bioSocials {
	max-height: 50px;
	max-width: 50px;
	width: 25%;
	height: auto;
	margin: 0 1%;
}
</style>
</head>

<body>
<!--style divs and logos, buttons, and bar start here-->
<div class="outer">
  <div class="inner">
    <div class="main">
      <p>
	<a href="/index.php"><img src="/Images/logo/logo.png" alt="Innersloth" class="logo"/></a><br/>
	<a href="/index.php"><img src="/Images/button_Games.png" alt="GAMES" class="buttons"/></a>
	<a href="/About.php"><img src="/Images/button_About.png" alt="ABOUT" class="buttons"/></a>  
	<a href="https://store.innersloth.com"><img src="/Images/button_Merch.png" alt="MERCH" class="buttons"/></a>
</p>
<hr style="width: 70%; height: auto; border-width: 2pt; border-color: #000000; border-style: solid; background-color: black">      <!--logos, buttons, and bar end here-->
      <h2>Meet our team!</h2>
      <div class="wrap"> 
        <!--Forest Post below-->
        <div id="leftPost"><img src="Images/ABOUT/bioImages/forestPortrait.png" class="bioImage" alt="Forest W."/>
          <h2>Forest W.</h2>
          <hr style="width: 70%; height: auto; border-width: 1pt; border-color: #000000; border-style: solid; background-color: black">
          <div style="text-align: left">
            <p>Hello, I'm your friendly neighborhood recluse/programmer! I also handle the business end of things at InnerSloth.</p>
            <p>When I'm not programming (basically always), I really enjoy bouldering.</p>
            <p>I don't post much on the internet, but I'm always open to questions about what we're doing and how it's done.</p>
          </div>
          <hr style="width: 70%; height: auto; border-width: 1pt; border-color: #000000; border-style: solid; background-color: black">
			<p style="font-weight: bold">Email: forest(at)innersloth(dot)com</p>
          <p><a href="https://twitter.com/forte_bass"><img src="Images/Twitter_Social_Icon_Rounded_Square_Color_small.png" class="bioSocials" alt="Twitter"></a> <a href="https://ForteBass.newgrounds.com/"><img src="Images/NG_TANK.png" class="bioSocials" alt="Newgrounds"></a></p>
        </div>
        <!--Marcus Post below-->
        <div id="centerPost"><img src="Images/ABOUT/bioImages/marcusPortrait.png" class="bioImage" alt="Marcus B"/>
          <h2>Marcus B.</h2>
          <hr style="width: 70%; height: auto; border-width: 1pt; border-color: #000000; border-style: solid; background-color: black">
          <div style="text-align: left">
            <p> Hello! I'm an artist, animator and game designer here at InnerSloth.</p>
            <p>You might know me as Puffballs United, the creator of Henry Stickmin Series! I worked on Among Us and recently finished the Henry Stickmin Collection. I also worked on Dig2China, and misc cancelled games ;)</p>
            <p>I've been wanting to make games since I was 8. Technology grew to the point that it was actually possible for me and not just a dream.</p>
            <p>I play a lot of games on the side.</p>
          </div>
          <hr style="width: 70%; height: auto; border-width: 1pt; border-color: #000000; border-style: solid; background-color: black">
			<p style="font-weight: bold">Email: marcus(at)innersloth(dot)com</p>
          <p><a href="https://twitter.com/PuffballsUnited"><img src="Images/Twitter_Social_Icon_Rounded_Square_Color_small.png" class="bioSocials" alt="Twitter"></a> <a href="https://PuffballsUnited.newgrounds.com/"><img src="Images/NG_TANK.png" class="bioSocials" alt="Newgrounds"></a> <a href="https://www.youtube.com/channel/UC7gxp8UVjU4tPPWTr4j4qNA"><img src="Images/youtube_social_squircle_red.png" class="bioSocials" alt="Youtube"/></a></p>
        </div>
        <!--Amy Post below-->
        <div id="rightPost"><img src="Images/ABOUT/bioImages/amyPortrait.png" class="bioImage" alt="Amy L"/>
          <h2>Amy L.</h2>
          <hr style="width: 70%; height: auto; border-width: 1pt; border-color: #000000; border-style: solid; background-color: black">
          <div style="text-align: left">
            <p>Heyo there! I'm the other artist here at InnerSloth. Also general task-doer for whatever else needs done!</p>
            <p>I worked on Among Us, and am currently working on developing merchandise and future Innersloth games!</p>
            <p>In my free time I enjoy photography, more drawing, taking naps, and hanging out with friends.</p>
          </div>
          <hr style="width: 70%; height: 1%; border-width: 1pt; border-color: #000000; border-style: solid; background-color: black">
			<p style="font-weight: bold">Email: amy(at)innersloth(dot)com</p>
          <p><a href="https://twitter.com/aemuuu"><img src="Images/Twitter_Social_Icon_Rounded_Square_Color_small.png" class="bioSocials" alt="Twitter"></a><a href="https://aemu.newgrounds.com/"><img src="Images/NG_TANK.png" class="bioSocials" alt="Newgrounds"></a><a href="https://aemuaemu.deviantart.com/"><img src="Images/devART.png" class="bioSocials" alt="deviantArt"/></a></p>
        </div>
      </div>
      
      <!--clearing floats-->
      <div style="clear:both;"></div>
      <hr style="width: 70%; height: auto; border-width: 2pt; border-color: #000000; border-style: solid; background-color: black">
      <h2>Contact us!</h2>
      <p>us (at) innersloth (dot) com</p>
      <p>InnerSloth<br/>
        PO Box 2532<br/>
        Redmond, WA 98073</p>
      <!--
      <div id="container">
        <p><img src="Images/ABOUT/bioImages/test.png" class="bioImage" alt="test"/><br/>
          A few lines of text</p>
        <p><img src="Images/ABOUT/bioImages/test.png" class="bioImage" alt="test"/><br/>
          More text with a different subject</p>
        <p><img src="Images/ABOUT/bioImages/test.png" class="bioImage" alt="test"/><br/>
          And more text with yet another subject</p>
      </div>
      <div class="row">
        <div class="bioColumns"><img src="Images/ABOUT/bioImages/test.png" class="bioImage" alt="test"/><br/>
          <p>Testing sdkfjh sdfkiusdf wsdefoihsdjf wodfoijsd fosdijfs foijsdfwejf egjd fowfjdjf sdoij woijsdfoiwer dfoweiujfjdj</p>
        </div>
        <div class="bioColumns"><img src="Images/ABOUT/bioImages/test.png" class="bioImage" alt="test"/>
          <p>Testing</p>
        </div>
        <div class="bioColumns"><img src="Images/ABOUT/bioImages/test.png" class="bioImage" alt="test"/>
          <p>Testing</p>
        </div>
      </div>--> 
      
      <!--Footer Starts--> 
    </div>
  </div>
  <p>
 <div id="mc_embed_signup">
  <form action="https://innersloth.us17.list-manage.com/subscribe/post?u=5f31c145a3f6a7f5225078d91&amp;id=1838435f9b" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
    <div><div>
          <input type="email" class="required email" id="mce-EMAIL" value="" name="EMAIL" placeholder=" Sign up to our newsletter with email!" style="line-height: 18pt; width: 200px; font-size: 9pt;">
        <input type="submit" value="SUBSCRIBE" name="subscribe" style="background: black; border-style: none; color: white; font-family: verdana, sans serif; font-size: 10pt; padding-top: 5pt; padding-bottom: 5pt; padding-left: 10pt; padding-right: 10pt;">
		</div>
            <div id="mce-responses">
		<div id="mce-error-response" style="display: none" class="responses"></div>
		<div id="mce-success-response" style="display:none" class="responses"></div>
	</div>
      <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
      <div style="position: absolute; left: -5000px;" aria-hidden="true">
        <input type="text" name="b_5f31c145a3f6a7f5225078d91_1838435f9b" tabindex="-1" value="">
      </div>
    </div>
  </form>
  <script type="text/javascript" src="//s3.amazonaws.com/downloads.mailchimp.com/js/mc-validate.js"></script> 
  <script type="text/javascript">(function($) {window.fnames = new Array(); window.ftypes = new Array();fnames[0]='EMAIL';ftypes[0]='email';fnames[1]='FNAME';ftypes[1]='text';fnames[2]='LNAME';ftypes[2]='text';}(jQuery));var $mcj = jQuery.noConflict(true);</script></div> 
  <!--End mc_embed_signup-->
  <p> 
	<a href="https://discord.gg/ZKBX694"><img src="Images/Discord-Logo-Color.png" alt="Discord" class="footer" style="margin-right: 10px;"></a>
	<a href="https://www.facebook.com/InnerSloth/"><img src="Images/FB-f-Logo__blue_50.png" alt="Facebook" class="footer" style="margin-right: 10px;"></a>
	<a href="https://twitter.com/InnerslothDevs"><img src="Images/Twitter_Social_Icon_Rounded_Square_Color_small.png" class="footer" alt="Twitter"></a>
	<a href="https://innersloth.newgrounds.com/"><img src="Images/NG_TANK.png" class="footer" alt="Newgrounds" style="margin-left: 10px;"></a>
  </p>
</p></div>
<!--Footer Ends-->
</body>
</html>
