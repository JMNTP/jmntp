<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>InnerSloth</title>
<meta name="description" content="An indie game company currently working on Among Us and The Henry Stickmin Collection">
<!--Website css base stuffs-->
<link rel="stylesheet" type="text/css" href="websiteStyle.css">
<style>
.container {
	/*banner image, src from https://www.w3schools.com/howto/tryit.asp?filename=tryhow_css_image_overlay_opacity*/
	position: relative;
	margin: auto;
	width: 80%;
}
.image {
	/*still banner image? lol*/
	opacity: 1;
	display: block;
	width: 100%;
	height: auto;
	transition: .5s ease;
	backface-visibility: hidden;
}
.middle {
	/*inner logo postitioning*/
	transition: .5s ease;
	opacity: 1; /*Change this if you want the logo to not appear unless rolled over*/
	position: absolute;
	top: 50%;
	left: 50%;
	transform: translate(-50%, -50%);
	-ms-transform: translate(-50%, -50%);
	text-align: center;
}
.container:hover .image {
	opacity: 0.3;
}
.container:hover .middle {
	opacity: 1;
}
.text {
	/*logo image*/
	color: white;
	width: 100%;
	height: auto;
}
div {
	text-align: center;
}
</style>
</head>

<body>
<!--style divs and logos, buttons, and bar start here-->
<div class="outer">
  <div class="inner">
    <div class="main">
	<p>
	<a href="/index.php"><img src="/Images/logo/logo.png" alt="Innersloth" class="logo"/></a><br/>
	<a href="/index.php"><img src="/Images/button_Games.png" alt="GAMES" class="buttons"/></a>
	<a href="/About.php"><img src="/Images/button_About.png" alt="ABOUT" class="buttons"/></a>  
	<a href="https://store.innersloth.com"><img src="/Images/button_Merch.png" alt="MERCH" class="buttons"/></a>
</p>
<hr style="width: 70%; height: auto; border-width: 2pt; border-color: #000000; border-style: solid; background-color: black">	<!--logos, buttons, and bar end here-->
      <p>
      <div class="container"><a href="gameDig2China.php"><img src="Images/GAMES/DigToChina/banner_DigToChina.png" alt="Dig to China" class="image" style="width:100%">
        <div class="middle">
          <div class="text"><img src="Images/GAMES/DigToChina/TITLE_TitleWords.png" alt="Dig to China" style="width: 100%; height: auto;"></div>
        </div>
        </a></div>
      </p>
      <p>
      <div class="container"><a href="gameHenryCollection.php"><img src="Images/GAMES/HenryCollection/banner_HenryCTM.jpg" alt="The Henry Stickmin Collection" class="image" style="width:100%">
        <div class="middle">
          <div class="text"><img src="Images/GAMES/HenryCollection/HSLogo.png" alt="The Henry Stickmin Collection" style="width: 55%; height: auto;"></div>
        </div>
        </a></div>
      </p>
      <p>
      <div class="container"><a href="gameAmongUs.php"><img src="Images/GAMES/AmongUs/banner_AmongUs.jpg" alt="Among Us" class="image" style="width:100%">
        <div class="middle">
          <div class="text"><img src="Images/GAMES/AmongUs/bannerLogo_AmongUs.png" alt="Among Us" style="width: 100%; height: auto;"></div>
        </div>
        </a></div>
      </p>
      <!--Footer Starts--> 
    </div>
  </div>
  <p>
 <div id="mc_embed_signup">
  <form action="https://innersloth.us17.list-manage.com/subscribe/post?u=5f31c145a3f6a7f5225078d91&amp;id=1838435f9b" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
    <div><div>
          <input type="email" class="required email" id="mce-EMAIL" value="" name="EMAIL" placeholder=" Sign up to our newsletter with email!" style="line-height: 18pt; width: 200px; font-size: 9pt;">
        <input type="submit" value="SUBSCRIBE" name="subscribe" style="background: black; border-style: none; color: white; font-family: verdana, sans serif; font-size: 10pt; padding-top: 5pt; padding-bottom: 5pt; padding-left: 10pt; padding-right: 10pt;">
		</div>
            <div id="mce-responses">
		<div id="mce-error-response" style="display: none" class="responses"></div>
		<div id="mce-success-response" style="display:none" class="responses"></div>
	</div>
      <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
      <div style="position: absolute; left: -5000px;" aria-hidden="true">
        <input type="text" name="b_5f31c145a3f6a7f5225078d91_1838435f9b" tabindex="-1" value="">
      </div>
    </div>
  </form>
  <script type="text/javascript" src="//s3.amazonaws.com/downloads.mailchimp.com/js/mc-validate.js"></script> 
  <script type="text/javascript">(function($) {window.fnames = new Array(); window.ftypes = new Array();fnames[0]='EMAIL';ftypes[0]='email';fnames[1]='FNAME';ftypes[1]='text';fnames[2]='LNAME';ftypes[2]='text';}(jQuery));var $mcj = jQuery.noConflict(true);</script></div> 
  <!--End mc_embed_signup-->
  <p> 
	<a href="https://discord.gg/ZKBX694"><img src="Images/Discord-Logo-Color.png" alt="Discord" class="footer" style="margin-right: 10px;"></a>
	<a href="https://www.facebook.com/InnerSloth/"><img src="Images/FB-f-Logo__blue_50.png" alt="Facebook" class="footer" style="margin-right: 10px;"></a>
	<a href="https://twitter.com/InnerslothDevs"><img src="Images/Twitter_Social_Icon_Rounded_Square_Color_small.png" class="footer" alt="Twitter"></a>
	<a href="https://innersloth.newgrounds.com/"><img src="Images/NG_TANK.png" class="footer" alt="Newgrounds" style="margin-left: 10px;"></a>
  </p>
</p></div>
<!--Footer Ends-->
</body>
</html>
